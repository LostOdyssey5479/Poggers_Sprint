
CREATE TABLE IF NOT EXISTS public.receipts
(
    receipt_id bigint NOT NULL,
    payment_method character varying COLLATE pg_catalog."default" NOT NULL,
    cost character varying COLLATE pg_catalog."default" NOT NULL,
    transaction_date character varying COLLATE pg_catalog."default" NOT NULL,
    order_id bigint,
    CONSTRAINT receipts_pkey PRIMARY KEY (receipt_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.receipts
    OWNER to postgres;
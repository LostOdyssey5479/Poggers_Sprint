
CREATE TABLE IF NOT EXISTS public.customer_account
(
    first_name character varying COLLATE pg_catalog."default" NOT NULL,
    last_name character varying COLLATE pg_catalog."default" NOT NULL,
    phone_number bigint NOT NULL,
    email character varying COLLATE pg_catalog."default" NOT NULL,
    address character varying COLLATE pg_catalog."default" NOT NULL,
    purchase_history bigint,
    customer_id bigint NOT NULL,
    order_id bigint,
    receipt_id bigint,
    CONSTRAINT customer_account_pkey PRIMARY KEY (customer_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.customer_account
    OWNER to postgres;
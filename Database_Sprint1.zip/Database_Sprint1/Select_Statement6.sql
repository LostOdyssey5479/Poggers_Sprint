SELECT orders.order_id, orders.order_type, inventory.stock
FROM orders
INNER JOIN inventory ON orders.stock = inventory.stock
select * from inventory 
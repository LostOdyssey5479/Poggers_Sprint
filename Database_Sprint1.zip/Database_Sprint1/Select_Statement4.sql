SELECT customer_account.first_name, customer_account.last_name, orders.customer_id 
FROM customer_account
INNER JOIN orders ON customer_account.order_id = orders.customer_id

CREATE TABLE IF NOT EXISTS public.inventory
(
    treat_id bigint NOT NULL,
    inventory_id bigint NOT NULL,
    stock bigint NOT NULL,
    CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.inventory
    OWNER to postgres;
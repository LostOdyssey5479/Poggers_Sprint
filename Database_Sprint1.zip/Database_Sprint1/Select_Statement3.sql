SELECT orders.order_id, orders.order_type, receipts.receipt_id 
FROM orders
INNER JOIN receipts ON orders.receipt_id = receipts.receipt_id
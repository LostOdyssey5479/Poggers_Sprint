SELECT customer_account.first_name, receipts.payment_method, receipts.receipt_id
FROM customer_account
INNER JOIN receipts ON customer_account.receipt_id = receipts.receipt_id
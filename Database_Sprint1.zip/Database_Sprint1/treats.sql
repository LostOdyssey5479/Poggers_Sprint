
CREATE TABLE IF NOT EXISTS public.treats
(
    treat_id bigint NOT NULL,
    treat_type character varying COLLATE pg_catalog."default",
    treat_name text COLLATE pg_catalog."default",
    inventory_id bigint,
    CONSTRAINT treats_pkey PRIMARY KEY (treat_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.treats
    OWNER to postgres;
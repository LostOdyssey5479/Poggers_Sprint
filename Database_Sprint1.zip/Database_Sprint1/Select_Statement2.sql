SELECT inventory.inventory_id, inventory.stock, treats.treat_id 
FROM inventory
INNER JOIN treats ON treats.inventory_id = treats.treat_id
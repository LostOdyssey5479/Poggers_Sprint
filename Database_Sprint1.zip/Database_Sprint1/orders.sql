
CREATE TABLE IF NOT EXISTS public.orders
(
    order_id bigint NOT NULL,
    order_type character varying COLLATE pg_catalog."default" NOT NULL,
    address character varying COLLATE pg_catalog."default",
    order_created_date character varying COLLATE pg_catalog."default",
    order_shipped_date character varying COLLATE pg_catalog."default",
    receipt_id bigint,
    customer_id bigint,
    stock bigint,
    CONSTRAINT orders_pkey PRIMARY KEY (order_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.orders
    OWNER to postgres;
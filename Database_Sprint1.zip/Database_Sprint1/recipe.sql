
CREATE TABLE IF NOT EXISTS public.recipe
(
    recipe_id bigint NOT NULL,
    recipe_desc character varying COLLATE pg_catalog."default" NOT NULL,
    treat_id bigint,
    CONSTRAINT recipe_pkey PRIMARY KEY (recipe_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.recipe
    OWNER to postgres;
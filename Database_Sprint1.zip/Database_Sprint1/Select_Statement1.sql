SELECT treats.treat_name, recipe.recipe_desc, recipe.recipe_id
FROM treats
INNER JOIN recipe ON treats.treat_id = recipe.treat_id
select * from recipe
select * from treats
const http = require("http");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const querystring = require("querystring");

const secretKey = "unfunny";

const server = http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/generate-token") {
    let requestBody = "";
    req.on("data", (chunk) => {
      requestBody += chunk;
    });

    req.on("end", () => {
      const { username } = querystring.parse(requestBody);

      const token = jwt.sign({ username }, secretKey);

      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ success: true, token }));
    });
  } else {
    fs.readFile("./views/webform.html", (err, data) => {
      if (err) {
        res.writeHead(500, { "Content-Type": "text/plain" });
        res.end("Internal Server Error");
      } else {
        res.writeHead(200, { "Content-Type": "text/html" });
        res.end(data);
      }
    });
  }
});

const port = 3000;
server.listen(port, () => {
  console.log(`Listening on http://localhost:${port}`);
});

const fs = require("fs");
const inquirer = require("inquirer");

const userRecordsPath = "userrecords.json";

function searchUserRecords(query) {
  const userRecords = JSON.parse(fs.readFileSync(userRecordsPath, "utf8"));

  const filteredRecords = userRecords.filter((record) => {
    const { username, email, phoneNumber } = record;
    return (
      username.includes(query) ||
      email.includes(query) ||
      phoneNumber.includes(query)
    );
  });

  return filteredRecords;
}

inquirer
  .prompt([
    {
      type: "input",
      name: "searchQuery",
      message: "Enter the search query (username, email, or phone number):",
    },
  ])
  .then((answers) => {
    const { searchQuery } = answers;
    const searchResults = searchUserRecords(searchQuery);

    if (searchResults.length > 0) {
      console.log("Search results:");
      searchResults.forEach((record) => {
        console.log("------------------");
        console.log(`Username: ${record.username}`);
        console.log(`Email: ${record.email}`);
        console.log(`Phone Number: ${record.phoneNumber}`);
      });
    } else {
      console.log("No matching user records found.");
    }
  })
  .catch((error) => {
    console.error("An error occurred:", error);
  });

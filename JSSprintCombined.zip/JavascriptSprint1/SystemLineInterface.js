const fs = require("fs");

function createDirectory(path) {
  try {
    fs.mkdirSync(path);
    console.log(`Created directory: ${path}`);
  } catch (error) {
    console.error(`Error creating directory: ${path}`, error);
  }
}

function createFile(filePath, fileContent) {
    try {
        fs.writeFileSync(filePath, fileContent);
        console.log(`Created file: ${filePath}`);
    } catch (error) {
        console.error(`Error creating file: ${filePath}`, error);
    }
}

function initializeApp(name) {
    createDirectory('app');
    createDirectory('config');

    createFile("app/index.js", name)
      
      }
initializeApp("Bob");
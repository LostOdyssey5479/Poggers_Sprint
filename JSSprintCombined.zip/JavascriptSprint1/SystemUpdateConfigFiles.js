const fs = require('fs');

const configFilePath = 'config/config.json';

function updateConfig(updatedConfig) {
  try {
    
    const existingConfigContent = fs.readFileSync(configFilePath, 'utf-8');

    const existingConfig = JSON.parse(existingConfigContent);

    const mergedConfig = { ...existingConfig, ...updatedConfig };

    const mergedConfigContent = JSON.stringify(mergedConfig, null, 2);

    fs.writeFileSync(configFilePath, mergedConfigContent);

    console.log('Configuration updated successfully.');
  } catch (error) {
    console.error('Error updating configuration:', error);
  }
}

const updatedConfig = {
  serverPort: 8080,
  databaseURL: 'mongodb://localhost:27017/myapp',
  someOtherOption: true
};

updateConfig(updatedConfig);


const fs = require('fs');

const originalConfigPath = 'config/original.json';
const currentConfigPath = 'config/current.json';

function resetConfig() {
  try {
    
    const originalConfigContent = fs.readFileSync(originalConfigPath, 'utf-8');

    fs.writeFileSync(currentConfigPath, originalConfigContent);

    console.log('Configuration reset to its original state.');
  } catch (error) {
    console.error('Error resetting configuration:', error);
  }
}

resetConfig();


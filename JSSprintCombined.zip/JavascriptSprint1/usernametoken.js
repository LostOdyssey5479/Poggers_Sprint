const jwt = require("jsonwebtoken");

const secretKey = "someunfunnymemeidk";

function generateUserToken(username) {
  const token = jwt.sign({ username }, secretKey);

  return token;
}

const username = process.argv[2];

if (!username) {
  console.error("Please provide a username as a command-line argument.");
  process.exit(1);
}

const userToken = generateUserToken(username);
console.log(`User Token: ${userToken}`);

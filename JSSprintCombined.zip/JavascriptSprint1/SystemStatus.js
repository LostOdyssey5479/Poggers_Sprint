const fs = require('fs');

function createDirectory(dirPath) {
  try {
    fs.mkdirSync(dirPath);
    console.log('Created directory: ' + dirPath);
  } catch (error) {
    console.error('Error creating directory: ' + dirPath, error);
  }
}

function createFile(filePath, fileContent) {
  try {
    fs.writeFileSync(filePath, fileContent);
    console.log('Created file: ' + filePath);
  } catch (error) {
    console.error('Error creating file: ' + filePath, error);
  }
}

function initializeApp() {
  console.log('Initializing application...');
  createDirectory('app');
  createDirectory('config');

  console.log('Creating app/index.js...');
  createFile('app/index.js', "function greet(name) {\n  console.log('Hello, ' + name + '!');\n}\n\ngreet('User');");

  console.log('Creating config/default.json...');
  createFile('config/default.json', JSON.stringify({
    "serverPort": 8080,
    "databaseURL": "mongodb://localhost:27017/myapp"
  }, null, 2));

  console.log('Creating config/help.txt...');
  createFile('config/help.txt', "Welcome to MyApp!\n\nTo get started, follow these instructions:\n\nStep 1: ...\nStep 2: ...\nStep 3: ...");

  console.log('Initialization and configuration completed successfully!');
}

initializeApp();
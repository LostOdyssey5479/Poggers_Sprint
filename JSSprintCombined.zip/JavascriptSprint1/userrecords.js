const fs = require("fs");
const inquirer = require("inquirer");

const userRecordsPath = "userrecords.json";

function updateUserRecord(username, email, phoneNumber) {
  const userRecords = JSON.parse(fs.readFileSync(userRecordsPath, "utf8"));

  const userRecord = userRecords.find((record) => record.username === username);

  if (userRecord) {
    if (email) userRecord.email = email;
    if (phoneNumber) userRecord.phoneNumber = phoneNumber;

    fs.writeFileSync(userRecordsPath, JSON.stringify(userRecords, null, 2));

    console.log("User record updated successfully.");
  } else {
    console.error("User record not found.");
  }
}

inquirer
  .prompt([
    {
      type: "input",
      name: "username",
      message: "Enter the username of the user:",
    },
    {
      type: "input",
      name: "email",
      message: "Enter the new email (Leave empty to skip):",
    },
    {
      type: "input",
      name: "phoneNumber",
      message: "Enter the new phone number (Leave empty to skip):",
    },
  ])
  .then((answers) => {
    const { username, email, phoneNumber } = answers;
    updateUserRecord(username, email, phoneNumber);
  })
  .catch((error) => {
    console.error("An error occurred:", error);
  });

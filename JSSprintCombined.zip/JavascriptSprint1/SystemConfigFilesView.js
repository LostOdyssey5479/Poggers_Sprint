const fs = require('fs');

function viewConfig(filePath) {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    console.log(`Current configuration file (${filePath}):`);
    console.log(fileContent);
  } catch (error) {
    console.error(`Error reading configuration file: ${filePath}`, error);
  }
}

function viewCurrentConfig() {
  console.log('Viewing current configuration...');

  const defaultConfigPath = 'config/default.json';
  const helpConfigPath = 'config/help.txt';

  viewConfig(defaultConfigPath);
  viewConfig(helpConfigPath);

  console.log('Configuration view complete!');
}

viewCurrentConfig();

